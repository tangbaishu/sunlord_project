/****************************************************************************
 * @copyright Copyright(C) 2020-2023 Ismartware Limited. All rights reserved.
 * @file i2c_slave.h
 * @brief Functions interfaces for the I2C firmware library
 * @author David
 ****************************************************************************/
#ifndef I2C_SLAVE_DRIVER_H
#define I2C_SLAVE_DRIVER_H

#include "system.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef enum
{
	MASTER_READ,
	MASTER_WRITE,
	MASTER_WRITE_FINISH,
	MASTER_READ_FINISH
}I2CS_Int_Event_e;	// I2C从机中断事件

extern I2CS_Int_Event_e	I2CS_Int_Event;

typedef void (*P_I2c_Slave_Int_Dispose) (I2CS_Int_Event_e event);

// This demo demostarates how to use i2c slave reading in sleep mode
void I2c_Slave_Driver_Init(P_I2c_Slave_Int_Dispose p_func);
// void I2c_Slave_Policy_Run();



#ifdef __cplusplus
}
#endif

#endif

