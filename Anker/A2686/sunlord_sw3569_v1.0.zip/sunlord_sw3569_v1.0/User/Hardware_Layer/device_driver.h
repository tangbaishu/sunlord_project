#ifndef _DEVICE_DRIVER_H_
#define _DEVICE_DRIVER_H_


unsigned int My_GetSystemTimePass(unsigned int tm);

unsigned int My_GetSystemTimeMark(void);

#endif
