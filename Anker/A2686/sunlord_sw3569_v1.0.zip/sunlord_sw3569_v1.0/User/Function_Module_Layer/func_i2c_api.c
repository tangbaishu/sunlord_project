#include "func_i2c_api.h"
#include "i2cm_async_driver.h"
#include "i2c_master_driver.h"
#include "i2c_slave_driver.h"
#include "zr_systick.h"
#include "zr_i2c.h"
#include "system.h"

void Func_I2C_Loop(I2C_API_Data_t *api_data);
bool Func_I2C_Write_Data(I2C_API_Data_t *api_data, uint8_t reg, uint8_t *p_write_data, uint8_t write_data_len);
bool Func_I2C_Read_Data(I2C_API_Data_t *api_data, uint8_t reg, uint8_t read_data_len);
void Func_I2C_Attach_Slave(I2C_API_Data_t *api_data, uint8_t device_addr, uint8_t overtime_seting);
static void Func_I2C_Slave_Event_Dispose(I2CS_Int_Event_e event);


void Func_I2C_API_Example(I2C_Driver_Type_e driver_type)
{
	static I2C_Driver_API_t I2C_Driver_API;
	static uint8_t	write_data[]={0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08,0x09,0x0A,0x0B,0x5a};
	static bool wrtie_en = true;
	Func_I2C_Driver_Init(driver_type, 50, &I2C_Driver_API);
	I2C_Driver_API.P_Func_Attach_Slave(&I2C_Driver_API.I2C_Driver_Data, 0x3c, 100);
	while(1)
	{
		if(wrtie_en)
		{
			MY_PRINTF("write\r\n");
			if( I2C_Driver_API.P_Func_Write_Data(&I2C_Driver_API.I2C_Driver_Data, 0x01, write_data, sizeof(write_data)) == SUCCESS)
			{
				wrtie_en = 0;
			}
		}
		else
		{
			if(	I2C_Driver_API.P_Func_Read_Data(&I2C_Driver_API.I2C_Driver_Data, 0x01, sizeof(write_data)) == SUCCESS)
			{
				MY_PRINTF("read\r\n");
			}

			if(I2C_Driver_API.I2C_Driver_Data.Driver_State.Reg_Read_Finish == true)
			{
				#if 1
						MY_PRINTF("i2cm async read data:\r\n");
						for(uint8_t num=0; num < sizeof(write_data); num++)
						{
							MY_PRINTF("read_data[%d] = %#x\r\n", num, I2C_Driver_API.I2C_Driver_Data.Read_Buffer.Read_Data[num]);
						}
						I2C_Driver_API.I2C_Driver_Data.Driver_State.Allow_Read_Write = true;
						I2C_Driver_API.I2C_Driver_Data.Driver_State.Reg_Read_Finish = false;
				#endif
				wrtie_en = 1;
			}
		}
		I2C_Driver_API.P_Func_Async_Thread(&I2C_Driver_API.I2C_Driver_Data);
		Systick_Delay_Ms(10);
	}
}

void Func_I2C_Driver_Init (I2C_Driver_Type_e driver_type, uint8_t freq_khz, I2C_Driver_API_t *I2C_Driver_API)
{
	if( I2C_SLAVE == driver_type )
	{
		I2c_Slave_Driver_Init(Func_I2C_Slave_Event_Dispose);
		return;
	}
	else if( I2C_MASTER_ASYNC == driver_type )
	{
		I2CM_Async_Hardware_Init(freq_khz);
		
	}
	I2C_Driver_API->P_Func_Write_Data = Func_I2C_Write_Data;
	I2C_Driver_API->P_Func_Read_Data = Func_I2C_Read_Data;
	I2C_Driver_API->P_Func_Attach_Slave = Func_I2C_Attach_Slave;
	I2C_Driver_API->P_Func_Async_Thread	= Func_I2C_Loop;
}

void Func_I2C_Loop(I2C_API_Data_t *api_data)
{
	uint8_t return_value;
	if(true == api_data->Driver_State.I2C_Running.Running)	// 若处于运行状态
	{
		return_value = 	I2cm_Async_Get_And_Clear_Finished(&((Func_I2CM_Async_Data_t *)(api_data->Driver_Support))->I2CS_Device);
		if( return_value == I2CM_RESULT_SUCCESS || return_value == I2CM_RESULT_FAILURE )
		{
			if(true == api_data->Driver_State.I2C_Running.Write_Running)
			{
				api_data->Driver_State.I2C_Running.Running = false;
				api_data->Driver_State.I2C_Running.Write_Running = false;
				api_data->Driver_State.Allow_Read_Write = true;
				MY_PRINTF("write_finish\r\n");
				return;
			}

			if(true == api_data->Driver_State.I2C_Running.Read_Running)
			{
				api_data->Driver_State.I2C_Running.Running = false;
				api_data->Driver_State.I2C_Running.Read_Running = false;
				api_data->Driver_State.Reg_Read_Finish = true;
				MY_PRINTF("read_finish\r\n");
				return;
			}
		}
		I2cm_Async_Run();

		if( I2CM_Async_Driver_Overtime( ((Func_I2CM_Async_Data_t *)(api_data->Driver_Support))->I2CM_Async_RAM,\
								 ((Func_I2CM_Async_Data_t *)(api_data->Driver_Support))->I2CM_Async_RAM.OverTime_Threshold ) )
		{
			#if defined(DEBUG_PRINTF_OPEN)
				// 超时
				#if 1
					MY_PRINTF("i2cm_async transfer overtime\r\n");
				#endif
			#endif
		}
	}
}

bool Func_I2C_Write_Data(I2C_API_Data_t *api_data, uint8_t reg, uint8_t *p_write_data, uint8_t write_data_len)
{
	if (	(api_data->Driver_State.I2C_Running.Write_Running == false) &&\
			(api_data->Driver_State.Allow_Read_Write == true) )
	{
		api_data->Driver_State.I2C_Running.Running = true;
		api_data->Driver_State.I2C_Running.Write_Running = true;
		if( I2C_MASTER_ASYNC == api_data->Driver_Type)
		{
			I2CM_Async_Driver_Write((Func_I2CM_Async_Data_t *)(api_data->Driver_Support), reg, p_write_data, write_data_len);
		}
		api_data->Driver_State.Allow_Read_Write = false;
		return SUCCESS;
	}
	return ERROR;
}

bool Func_I2C_Read_Data(I2C_API_Data_t *api_data, uint8_t reg, uint8_t read_data_len)
{
	if (	(api_data->Driver_State.I2C_Running.Read_Running == false) &&\
			(api_data->Driver_State.Allow_Read_Write == true) )
	{
		api_data->Driver_State.I2C_Running.Running = true;
		api_data->Driver_State.I2C_Running.Read_Running = true;
		if( I2C_MASTER_ASYNC == api_data->Driver_Type)
		{
			Func_I2CM_Async_Driver_Read((Func_I2CM_Async_Data_t *)(api_data->Driver_Support), reg, read_data_len);
		}
		api_data->Driver_State.Allow_Read_Write = false;
		return SUCCESS;
	}
	return ERROR;
}

static void Async_Attach_Slave(I2C_API_Data_t *api_data, uint8_t device_addr, uint8_t overtime_seting)
{
	static Func_I2CM_Async_Data_t i2cm_async_data;
	I2CM_Async_Driver_Attach_Slave(&i2cm_async_data, device_addr, i2cm_async_data.Buffer_Area, IIC_BUFFER_AREA_LEN, overtime_seting);
	api_data->Driver_Support = (uint32_t*) &i2cm_async_data;
	api_data->Read_Buffer.Read_Data = i2cm_async_data.Buffer_Area;
} 

void Func_I2C_Attach_Slave(I2C_API_Data_t *api_data, uint8_t device_addr, uint8_t overtime_seting)
{
	if(I2C_MASTER_ASYNC == api_data->Driver_Type)
	{
		Async_Attach_Slave(api_data, device_addr, overtime_seting);
		api_data->Driver_State.Allow_Read_Write = true;
	}
}

/**
 * @brief 响应主机数据读取请求
 * 
 */
static void Func_I2CS_Response_Read(void)
{
	uint8_t visit_reg = 0; // 主机请求响应寄存器
	static uint8_t gReg0x1Data[] = {0xF0,0xE0,0xD0,0xE0,0xC0,0xB0,0xA0,0x90,0x80};
	static uint8_t buffer[8]={0};
	volatile uint8_t i = 0;
	visit_reg = I2c_Slave_Get_Register_Address();
	switch(visit_reg)
	{
		case 0x01:
				for(;i<8;i++)
				{
					ZR_I2C->S_TX_DATA = gReg0x1Data[i];
				}
			break;
	
	default:
		break;
	}
	I2c_Slave_Get_RX_Data(buffer, 8); 
	I2c_Slave_RX_FIFO_Reset();
	I2c_Slave_TX_FIFO_Reset();
	// MY_PRINTF("r%d\r\n",visit_reg);
	// for(uint8_t num=0; num < 8; num++)
	// {
	// 	MY_PRINTF("R[%d]=%#x\r\n", num, buffer[num]);
	// }
}

/**
 * @brief 处理主机发送命令
 * 
 */
static void Func_I2CS_Rx_CMD_Dispose(void)
{
	uint8_t visit_reg = 0, rx_length; // 主机请求响应寄存器
	static uint8_t buffer[8]={0};
	
	visit_reg = I2c_Slave_Get_Register_Address();
	MY_PRINTF("w%d\r\n",visit_reg);
	
	// switch (visit_reg)
	// {
	// 	case 0x01: I2c_Slave_Get_RX_Data(buffer, 8); I2c_Slave_RX_FIFO_Reset(); break;
	
	// default: break;
	// }
	// do
	// {
		I2c_Slave_Get_RX_Data(buffer, 8); I2c_Slave_RX_FIFO_Reset();
		for(uint8_t num=0; num < 8; num++)
		{
			MY_PRINTF("W[%d]=%#x\r\n", num, buffer[num]);
		}
	// } while (I2c_Slave_Get_Pending(I2C_S_FINISH_PENGING) != 1);
	// if(SLAVE_ROUSE == visit_reg)	// 唤醒
	// {
	// 	*Func_I2C_Slave_Data.I2C_Running_State = BUSY_STATE;
	// 	// Low_Power_Not_Sleep();
	// }
	// else if(SLAVE_SLEEP == visit_reg)	// 睡眠
	// {
	// 	*Func_I2C_Slave_Data.I2C_Running_State = LEISURE_STATE;
	// }
	// else if(PORT2_CTL_OUT_POWER == visit_reg)
	// {
	// 	rx_length = I2c_Slave_Get_RX_Byte_Length();
	// 	I2c_Slave_Get_RX_Data(Func_I2C_Slave_Data.Port2_Seting_Output_Power, rx_length);
	// }

}


void Func_I2C_Slave_Event_Dispose(I2CS_Int_Event_e event)
{
	static uint8_t buffer[8]={0};
	static uint8_t gReg0x1Data[] = {0xFF,0xEE,0xDD,0xEE,0xCC,0xBB,0xAA,0x99,0x88};
	if(MASTER_READ == event)
	{
		Func_I2CS_Response_Read();
	}
	else if(MASTER_WRITE == event)
	{
		Func_I2CS_Rx_CMD_Dispose();
	}
	else if(MASTER_WRITE_FINISH == event)
	{
		I2c_Slave_Get_RX_Data(buffer, 8); I2c_Slave_RX_FIFO_Reset();
		for(uint8_t num=0; num < 8; num++)
		{
			MY_PRINTF("WF[%d]=%#x\r\n", num, buffer[num]);
		}
	}
	else if(MASTER_READ_FINISH == event)
	{
		I2c_Slave_Get_RX_Data(buffer, 8); I2c_Slave_RX_FIFO_Reset();
		for(uint8_t num=0; num < 8; num++)
		{
			MY_PRINTF("WF[%d]=%#x\r\n", num, buffer[num]);
		}
	}
}

