#include "func_i2c_slave.h"
#include "i2c_protocol_library.h"
#include "i2c_slave_driver.h"
#include "zr_i2c.h"
#include "api.h"

Func_I2C_Slave_Data_t	Func_I2C_Slave_Data;

/**
 * @brief 响应主机数据读取请求
 * 
 */
static void Func_I2CS_Response_Read(void);

/**
 * @brief 处理主机发送命令
 * 
 */
static void Func_I2CS_Rx_CMD_Dispose(void);

void Func_I2CS_Dispose(I2CS_Int_Event_e event)
{

}

