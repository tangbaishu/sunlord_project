/**
 * @file func_gather_temp.h		温度采集函数
 * @author tong.libo@sunlord.com.cn
 * @brief 
 * @version 0.1
 * @date 2024-12-20
 * 
 * @copyright Copyright (c) 2024
 * 
 */