#include "busi_port_detection.h"
#include "busi_i2c_bus.h"
#include "sunlord_api.h"
#include "zr_adc.h"
#include "api.h"

#if defined(DEBUG_PRINTF_OPEN)
    #include "stdio.h"
    #define LOG "busi_p_d: "
#endif
static bool Port1_Power_Adjust_Callback(uint16_t* vol, uint16_t* port1Curr, uint16_t* port2Curr);


static uint8_t Host_Get_Port_Link_State_Func (void);
static void Host_Get_Port_Out_Protocol_Func (uint8_t link_port_num);
static RealTime_Out_Power_t Host_Get_Port_RealTime_Out_Power_Func (uint8_t link_port_num);

static uint8_t Slave_Get_Port_Link_State_Func (void);
static void Slave_Get_Port_Out_Protocol_Func (uint8_t link_port_num);
static RealTime_Out_Power_t Slave_Get_Port_RealTime_Out_Power_Func (uint8_t link_port_num);

Port_Detection_Data_t	Busi_Port_Detection_Data={
	.P_Port_BSP_Data		 	= &Hardware_BSP_Data,
};


Busi_Port_Detection_Func_t Busi_Port_Detection_Func;

void Busi_Port_Detection_Init(void)
{
	current_limitation_callback
	if(HOST_DEVICE == Busi_Port_Detection_Data.P_Port_BSP_Data->Device_Type)
	{
		Busi_Port_Detection_Func.Port_Link_Detection 		= Host_Get_Port_Link_State_Func;
		Busi_Port_Detection_Func.Port_Out_Protocol 			= Host_Get_Port_Out_Protocol_Func;
		Busi_Port_Detection_Func.Port_RealTime_Out_Power 	= Host_Get_Port_RealTime_Out_Power_Func;
	}
	else if (SLAVE_DEVICE == Busi_Port_Detection_Data.P_Port_BSP_Data->Device_Type)
	{
		Busi_Port_Detection_Func.Port_Link_Detection 		= Slave_Get_Port_Link_State_Func;
		Busi_Port_Detection_Func.Port_Out_Protocol 			= Slave_Get_Port_Out_Protocol_Func;
		Busi_Port_Detection_Func.Port_RealTime_Out_Power 	= Slave_Get_Port_RealTime_Out_Power_Func;
	}
	Device_Register_Power_Adjust_Hook(Port1_Power_Adjust_Callback);
	Get_All_Port_Link_State();
}

void Get_All_Port_Link_State(void)
{
	Busi_Port_Detection_Func.Port_Link_Detection();
}

static bool Port1_Power_Adjust_Callback(uint16_t* vol, uint16_t* port1Curr, uint16_t* port2Curr)
{
	#if defined(DEBUG_PRINTF_OPEN)
		printf(LOG"Port_Power_Adjust_Callback V=%d, I1=%d, I2=%d\r\n", *vol, *port1Curr, *port2Curr);
	#endif
	if(READ_BIT(Busi_Port_Detection_Data.Port_Out_Protocol_Data.Port_Link_State, 0x01) == 0x01)	// 端口处于插入状态
	{
		Busi_Port_Detection_Data.Port_Out_Protocol_Data.Port_Info[0].Protocol_Type = Device_Get_Protocol(1);
		if(0 == Busi_Port_Detection_Data.Port_Out_Protocol_Data.Port_Info[0].Protocol_Type)
		{
			Busi_Port_Detection_Data.Port_Out_Protocol_Data.Port_Info[0].Protocol_Voltage = 0;
		}
		else
		{
			Busi_Port_Detection_Data.Port_Out_Protocol_Data.Port_Info[0].Protocol_Current = *port1Curr * 25;
		}
		Busi_Port_Detection_Data.Port_Out_Protocol_Data.Port_Info[0].Protocol_Voltage = *vol * 10;
		#if defined(DEBUG_PRINTF_OPEN)
		printf(LOG"Port1_Power_Adjust_Callback V=%d, I=%d, Protocol=%d\r\n",\
						Busi_Port_Detection_Data.Port_Out_Protocol_Data.Port_Info[0].Protocol_Voltage,\
						Busi_Port_Detection_Data.Port_Out_Protocol_Data.Port_Info[0].Protocol_Current,\
						(uint8_t)Busi_Port_Detection_Data.Port_Out_Protocol_Data.Port_Info[0].Protocol_Type);
		#endif
	}
	return false;
}

/**
 * @brief 检索端口连接状态
 * @param return 0：所有端口均为插入，1：端口1插入，2：端口2插入
 */
static uint8_t Host_Get_Port_Link_State_Func (void)
{
	uint8_t port_link_num;
	
	return port_link_num;
}

/**
 * @brief 主机获取当前插入端口号的输出协议数据
 * 仅适用于所有芯片自身映射的外部端口为1的情况,且主机端口号为1
 * @param link_port_num 插入的实际端口号，例如：link_port_num = 1，对应主机端口1；link_port_num = 2,对应1号从机端口1
 */
static void Host_Get_Port_Out_Protocol_Func (uint8_t link_port_num)
{
	if(link_port_num == 0)
	{
		Busi_Port_Detection_Data.Port_Out_Protocol_Data.Port_Info[link_port_num].Protocol_Voltage = Device_Get_Requesting_Voltage();
		Busi_Port_Detection_Data.Port_Out_Protocol_Data.Port_Info[link_port_num].Protocol_Type = Device_Get_Protocol(1);
	}
	else
	{

	}
}

/**
 * @brief 主机获取当前插入端口号的实时输出功率
 * 仅适用于所有芯片自身映射的外部端口为1的情况,且主机端口号为1
 * @param link_port_num 插入的实际端口号，例如：link_port_num = 1，对应主机端口1；link_port_num = 2,对应1号从机端口1
 */
static RealTime_Out_Power_t Host_Get_Port_RealTime_Out_Power_Func (uint8_t link_port_num)
{
	if(link_port_num == 0)
	{
		Busi_Port_Detection_Data.Port_RealTime_Out_Power[link_port_num].Voltage = Adc_Vout_Get();		// unit:mV
		Busi_Port_Detection_Data.Port_RealTime_Out_Power[link_port_num].Current = Adc_Iout_Get(0);	// unit:mA
		Busi_Port_Detection_Data.Port_RealTime_Out_Power[link_port_num].Power = \
		(Busi_Port_Detection_Data.Port_RealTime_Out_Power[link_port_num].Voltage * Busi_Port_Detection_Data.Port_RealTime_Out_Power[link_port_num].Current) \
		/ 1000;	// 将其变成 mW 
		#if defined(DEBUG_PRINTF_OPEN)
		printf(LOG"Port1_Real_Power V=%d, I=%d, P=%d\r\n", Busi_Port_Detection_Data.Port_RealTime_Out_Power[link_port_num].Voltage,\
								Busi_Port_Detection_Data.Port_RealTime_Out_Power[link_port_num].Current, \
								Busi_Port_Detection_Data.Port_RealTime_Out_Power[link_port_num].Power);
		#endif
	}
	else
	{

	}
	return Busi_Port_Detection_Data.Port_RealTime_Out_Power[link_port_num];
}

static uint8_t Slave_Get_Port_Link_State_Func (void)
{
	uint8_t port_link_num;
	
	return port_link_num;
}

static void Slave_Get_Port_Out_Protocol_Func (uint8_t link_port_num)
{
	Busi_Port_Detection_Data.Port_Out_Protocol_Data.Port_Info[0].Protocol_Voltage = Device_Get_Requesting_Voltage();
	Busi_Port_Detection_Data.Port_Out_Protocol_Data.Port_Info[0].Protocol_Type = Device_Get_Protocol(1);
}

static RealTime_Out_Power_t Slave_Get_Port_RealTime_Out_Power_Func (uint8_t link_port_num)
{
	Busi_Port_Detection_Data.Port_RealTime_Out_Power[0].Voltage = Adc_Vout_Get();		// unit:mV
	Busi_Port_Detection_Data.Port_RealTime_Out_Power[0].Current = Adc_Iout_Get(0);	// unit:mA
	Busi_Port_Detection_Data.Port_RealTime_Out_Power[0].Power = \
	(Busi_Port_Detection_Data.Port_RealTime_Out_Power[0].Voltage * Busi_Port_Detection_Data.Port_RealTime_Out_Power[0].Current) \
	/ 1000;	// 将其变成 mW 
	#if defined(DEBUG_PRINTF_OPEN)
	printf(LOG"Port1_Real_Power V=%d, I=%d, P=%d\r\n", Busi_Port_Detection_Data.Port_RealTime_Out_Power[0].Voltage,\
							Busi_Port_Detection_Data.Port_RealTime_Out_Power[0].Current, \
							Busi_Port_Detection_Data.Port_RealTime_Out_Power[0].Power);
	#endif
	return Busi_Port_Detection_Data.Port_RealTime_Out_Power[link_port_num];
}
