/**
 * @file busi_port_detection.h	端口检测业务
 * @author 	tong.libo@sunlord.com.cn
 * @brief 
 * @version 0.1
 * @date 2024-12-20
 * 
 * @copyright Copyright (c) 2024
 * 
 */

#ifndef _BUSI_PORT_DETECTION_H_
#define _BUSI_PORT_DETECTION_H_

#include "system.h"
#include "port_data_library.h"
#include "func_power_alloc.h"
#include "func_hardware_api.h"
#include "api.h"

typedef struct
{
	bool						Port_State_Updata;				// 1: 状态更新 0：状态未更新
	Hardware_Driver_Data_t		*P_Port_BSP_Data;				// 所有端口板端数据
	Port_Out_Info_t				Port_Out_Protocol_Data;			// 所有端口输出数据
	RealTime_Out_Power_t		Port_RealTime_Out_Power[SYS_PORT_MAX_NUMBER];		// 所有端口实时输出功率
}Port_Detection_Data_t;
extern Port_Detection_Data_t	Busi_Port_Detection_Data; 

/**
 * @brief 检索端口连接状态
 * @param return 0：所有端口均为插入，1：端口1插入，2：端口2插入
 */
typedef uint8_t (*P_Port_Link_Detection) (void);

/**
 * @brief 主机获取当前插入端口号的输出协议数据
 * 仅适用于所有芯片自身映射的外部端口为1的情况,且主机端口号为1
 * @param link_port_num 插入的实际端口号，例如：link_port_num = 1，对应主机端口1；link_port_num = 2,对应1号从机端口1
 */
typedef void (*P_Port_Out_Protocol) (uint8_t link_port_num);

/**
 * @brief 主机获取当前插入端口号的实时输出功率
 * 仅适用于所有芯片自身映射的外部端口为1的情况,且主机端口号为1
 * @param link_port_num 插入的实际端口号，例如：link_port_num = 1，对应主机端口1；link_port_num = 2,对应1号从机端口1
 */
typedef RealTime_Out_Power_t (*P_Port_RealTime_Out_Power) (uint8_t link_port_num);

typedef struct
{
	P_Port_Link_Detection		Port_Link_Detection;
	P_Port_Out_Protocol			Port_Out_Protocol;
	P_Port_RealTime_Out_Power	Port_RealTime_Out_Power;
}Busi_Port_Detection_Func_t;
extern Busi_Port_Detection_Func_t Busi_Port_Detection_Func;

void Busi_Port_Detection_Init(void);
void Get_All_Port_Link_State(void);

#endif
