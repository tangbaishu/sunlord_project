#include "busi_i2c_bus.h"
#include "func_hardware_init.h"

I2C_Transfer_Data_t I2C_Transfer_Data = {.I2C_Running_State = (uint8_t *)&I2C_M_Driver.Runing_State};

void Busi_I2C_Get_Port2_Data(Port2_Data_Type_e data_type)
{
	Transfer_Info_t transfer_info;
	transfer_info.Wdata_Len = 0;
	if(OUT_PROTOCOL == data_type)
	{
		transfer_info.Reg_Addr = PORT2_OUT_PROTOCOL;
		transfer_info.Rdata_Len = sizeof(I2C_Transfer_Data.Port2_Out_Protocol_Data);
		transfer_info.P_Rdata = (uint8_t *)&I2C_Transfer_Data.Port2_Out_Protocol_Data;
		Func_Fast_Charge_Driver.IIC_Master_Driver.P_I2C_Master_Read_NByte(&transfer_info);
	}
	else if(OUT_REALTIME_POWER == data_type)
	{
		transfer_info.Reg_Addr = PORT2_REALTIME_POWER;
		transfer_info.Rdata_Len = sizeof(I2C_Transfer_Data.Port2_RealTime_Out_Power);
		transfer_info.P_Rdata = (uint8_t *)&I2C_Transfer_Data.Port2_RealTime_Out_Power;
		Func_Fast_Charge_Driver.IIC_Master_Driver.P_I2C_Master_Read_NByte(&transfer_info);
	}

}

void Busi_I2C_Get_Port2_Temp_State(void)
{
	Transfer_Info_t transfer_info;
	transfer_info.Wdata_Len = 0;
	transfer_info.Reg_Addr = PORT2_NTC_TEMP_DATA;
	transfer_info.Rdata_Len = sizeof(I2C_Transfer_Data.NTC_Temp_Data);
	transfer_info.P_Rdata = (uint8_t *)&I2C_Transfer_Data.NTC_Temp_Data;
	Func_Fast_Charge_Driver.IIC_Master_Driver.P_I2C_Master_Read_NByte(&transfer_info);
}

void Busi_I2C_Ctl_Port2_Power(void)
{
	Transfer_Info_t transfer_info;
	transfer_info.Reg_Addr = PORT2_CTL_OUT_POWER;
	transfer_info.Wdata_Len = 1;
	transfer_info.P_Wdata[0] = I2C_Transfer_Data.Port2_Seting_Output_Power;
	Func_Fast_Charge_Driver.IIC_Master_Driver.P_I2C_Master_Write_NByte(&transfer_info);
}