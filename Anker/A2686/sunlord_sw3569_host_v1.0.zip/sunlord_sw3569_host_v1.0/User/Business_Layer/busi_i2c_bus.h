/**
 * @file busi_i2c_bus.h
 * @author tong.libo@sunlord.com.cn
 * @brief 
 * I2C数据传输协议规定
 * i2c数据传输业务
 * 待传输业务：
 * 		busi_port_detection.h 文件下：
 * 			Port_Detection_Data_t	Busi_Port_Detection_Data; 内有关Port2的各项数据
 * 			 	具体如下：
 * 					Port_Out_Protocol_Data_t	Port2_Out_Protocol_Data;	--> 寄存器1
 * 						Port_Link_State_e		Port_Link_State;		// 端口连接状态
						fast_charge_protocol_e	Protocol_Type;			// 端口协议类型
						uint16_t 				Protocol_Voltage;		// 端口输出电压
						uint16_t 				Protocol_Current;		// 端口输出电流
						POWER_PDO_Mode_e		Current_Power_Grade; 	// 当前端口输出协议等级
 * 					Port_RealTime_Out_Power_t	Port2_RealTime_Out_Power;	--> 寄存器2
						uint16_t				Voltage;				// 实时电压 unit: mV
						uint16_t				Current;				// 实时电流 unit: mA
						uint16_t				Power;					// 实时功率 unit: mW
 * 		ntc_temp_sample.h 文件下：
 * 			NTC_Temp_Data_t	NTC_Temp_Data; 内有关Port2的各项数据			--> 寄存器3
 * 				具体如下：
 * 					NTC_Temp_State_e	NTC_Over_Temp_Flag;				// NTC过温标志
 * 					OverTemp_Dispose_e	OverTemp_Dispose_Flag;			// NTC过温处理标志
 * 		busi_fast_charge_config.h 文件下：
 * 			POWER_PDO_Mode_e  控制从机输出对应功率等级
 * 
 * 通讯协议如下：
 * 		从机地址：0x3c
 * 		仅读：
 * 		寄存器 PORT2_OUT_PROTOCOL: 		Port_Out_Protocol_Data_t	Port2_Out_Protocol_Data 地址：0x01
 * 		寄存器 PORT2_REALTIME_POWER:	Port_RealTime_Out_Power_t	Port2_RealTime_Out_Power  地址：0x02
 * 		读写：
 * 		寄存器 PORT2_NTC_TEMP_DATA:		NTC_Temp_Data_t	NTC_Temp_Data 地址：0x03
 * 		仅写：
 * 		寄存器 PORT2_CTL_OUT_POWER:		POWER_PDO_Mode_e 地址：0x04
 * 		

 * @version 0.1
 * @date 2024-12-26
 * 
 * @copyright Copyright (c) 2024
 * 
 */
#ifndef _BUSI_I2C_BUS_H_
#define _BUSI_I2C_BUS_H_

#include "busi_port_detection.h"
#include "ntc_temp_sample.h"

typedef enum
{
	OUT_PROTOCOL,
	OUT_REALTIME_POWER,
}Port2_Data_Type_e;

typedef enum
{
	PORT2_OUT_PROTOCOL = 0x01,
	PORT2_REALTIME_POWER,
	PORT2_NTC_TEMP_DATA,
	PORT2_CTL_OUT_POWER,		// 控制端口2输出功率
}I2C_Register_List_e;

typedef struct
{
	bool	Finish;
	bool	Busy;
}I2C_Running_State_t;


typedef struct 
{
	Port_Out_Protocol_Data_t	Port2_Out_Protocol_Data;
	Port_RealTime_Out_Power_t	Port2_RealTime_Out_Power;
	NTC_Temp_Data_t				NTC_Temp_Data;
	POWER_PDO_Mode_e			Port2_Seting_Output_Power;
	I2C_State_e					*I2C_Running_State;
}I2C_Transfer_Data_t;
extern I2C_Transfer_Data_t I2C_Transfer_Data;

void Busi_I2C_Get_Port2_Data(Port2_Data_Type_e data_type);
void Busi_I2C_Get_Port2_Temp_State(void);
void Busi_I2C_Ctl_Port2_Power(void);




#endif // !_BUSI_I2C_BUS_H_