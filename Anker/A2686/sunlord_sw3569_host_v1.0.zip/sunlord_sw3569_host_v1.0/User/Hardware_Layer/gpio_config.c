#include "gpio_config.h"
#include "zr_gpio.h"
#if defined(DEBUG_PRINTF_OPEN)
    #include "stdio.h"
    #define LOG "g_c: "
#endif

void Gpio_Fast_Charge_C1_Config(void)
{

}